package models;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class Task {
    private int id;
    private String title;
    private String status;      // "open" or "closed"
    private String addedBy;
    private LocalDate creationDate;
    
    public Task(int id, String title, String status, String addedBy, LocalDate creationDate) {
        this.id = id;
        this.title = title;
        this.status = status;
        this.addedBy = addedBy;
        this.creationDate = creationDate;
    }
    
    public int getId() {
        return id;
    }
    
    public String getTitle() {
        return title;
    }
    
    public String getStatus() {
        return status;
    }
    
    public String getAddedBy() {
        return addedBy;
    }
    
    public LocalDate getCreationDate() {
        return creationDate;
    }
    
    public void setStatus(String status) {
        this.status = status;
    }
    
    public void setTitle(String title) {
        this.title = title;
    }
    
    //  displaying 
    @Override
    public String toString() {
        return id + " - " + title + " [" + status + "] by " + addedBy + " on " + creationDate;
    }
    
    //  creating section headers
    public static String createHeader(String headerText) {
        return "=== " + headerText.toUpperCase() + " ===";
    }
}