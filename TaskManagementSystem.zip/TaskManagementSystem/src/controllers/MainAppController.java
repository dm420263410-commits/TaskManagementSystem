package controllers;

import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Comparator;
import java.util.Map;
import java.util.Optional;
import java.util.ResourceBundle;
import java.util.stream.Collectors;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.control.TextInputDialog;
import models.Task;

public class MainAppController implements Initializable {
    
    @FXML
    private ListView<Object> listView;
    @FXML
    private Label totalTasksLabel;
    @FXML
    private Label resultLabel;
    
    // Add Task Form Fields
    @FXML
    private TextField titleField;
    @FXML
    private TextField statusField;
    @FXML
    private TextField addedByField;
    @FXML
    private DatePicker datePicker;
    @FXML
    private Button addTaskBtn;
    
    // Operation Buttons
    @FXML
    private Button viewByPersonBtn;
    @FXML
    private Button earliestFourBtn;
    @FXML
    private Button startWithABtn;
    @FXML
    private Button mostActiveBtn;
    @FXML
    private Button countByStatusBtn;
    @FXML
    private Button countByPersonBtn;
    @FXML
    private Button showAllBtn;
    
    private Map<Integer, Task> tasksMap;
    private int nextId;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        loadTasksFromCSV();
        displayAllTasks();
        updateTotalTasksLabel();
    }
    
    // Load tasks from CSV file 
    private void loadTasksFromCSV() {
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        try {
            tasksMap = Files.lines(Paths.get("data/tasks.csv"))
                    .skip(1) 
                    .map(line -> line.split(","))
                    .map(data -> new Task(
                            Integer.parseInt(data[0].trim()),
                            data[1].trim(),
                            data[2].trim(),
                            data[3].trim(),
                            LocalDate.parse(data[4].trim(), formatter)
                    ))
                    .collect(Collectors.toMap(Task::getId, task -> task));
            
            // Calculate ID
            nextId = tasksMap.keySet().stream().max(Integer::compareTo).orElse(0) + 1;
        } catch (IOException ex) {
            showAlert("Error", "Failed to load tasks from CSV file.", Alert.AlertType.ERROR);
            tasksMap = FXCollections.observableHashMap();
            nextId = 1;
        }
    }
    
    // Display all tasks 
    private void displayAllTasks() {
        listView.getItems().clear();
        listView.getItems().addAll(tasksMap.values());
    }
    
    // Update 
    private void updateTotalTasksLabel() {
        totalTasksLabel.setText("Total Tasks: " + tasksMap.size());
    }
    
    // Add new task 
    @FXML
    private void addTaskHandle(ActionEvent event) {
        String title = titleField.getText().trim();
        String status = statusField.getText().trim().toLowerCase();
        String addedBy = addedByField.getText().trim();
        LocalDate date = datePicker.getValue();
        
        // Validation
        if (title.isEmpty()) {
            showAlert("Validation Error", "Title must not be empty.", Alert.AlertType.ERROR);
            return;
        }
        if (!status.equals("open") && !status.equals("closed")) {
            showAlert("Validation Error", "Status must be 'open' or 'closed'.", Alert.AlertType.ERROR);
            return;
        }
        if (addedBy.isEmpty()) {
            showAlert("Validation Error", "Added By must not be empty.", Alert.AlertType.ERROR);
            return;
        }
        if (date == null) {
            showAlert("Validation Error", "Please select a valid date.", Alert.AlertType.ERROR);
            return;
        }
        
        Task newTask = new Task(nextId++, title, status, addedBy, date);
        tasksMap.put(newTask.getId(), newTask);
        displayAllTasks();
        updateTotalTasksLabel();
        
       
        titleField.clear();
        statusField.clear();
        addedByField.clear();
        datePicker.setValue(null);
        
        showAlert("Success", "Task added successfully!", Alert.AlertType.INFORMATION);
    }
    
    // View tasks by specific user, sorted by ID 
    @FXML
    private void viewTasksByPersonHandle(ActionEvent event) {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("View Tasks by Person");
        dialog.setHeaderText("Enter person's name (e.g., Ali)");
        dialog.setContentText("Name:");
        
        Optional<String> result = dialog.showAndWait();
        result.ifPresent(person -> {
            listView.getItems().clear();
            tasksMap.values().stream()
                    .filter(task -> task.getAddedBy().equalsIgnoreCase(person))
                    .sorted(Comparator.comparingInt(Task::getId))
                    .forEach(task -> listView.getItems().add(task));
                    
            if (listView.getItems().isEmpty()) {
                resultLabel.setText("No tasks found for " + person);
            } else {
                resultLabel.setText("Tasks by " + person + " (sorted by ID) - Count: " + listView.getItems().size());
            }
        });
    }
    
    // Show earliest 4 tasks by creation date
    @FXML
    private void showEarliestFourHandle(ActionEvent event) {
        listView.getItems().clear();
        tasksMap.values().stream()
                .sorted(Comparator.comparing(Task::getCreationDate))
                .limit(4)
                .forEach(task -> listView.getItems().add(task));
        resultLabel.setText("Earliest 4 tasks by creation date");
    }
    
    // Show tasks starting with 'a' and exactly 7 letters (Requirement 8)
    @FXML
    private void showTasksStartingWithAHandle(ActionEvent event) {
        listView.getItems().clear();
        tasksMap.values().stream()
                .filter(task -> task.getTitle().toLowerCase().startsWith("a"))
                .filter(task -> task.getTitle().length() == 7)
                .forEach(task -> listView.getItems().add(task));
        resultLabel.setText("Tasks starting with 'a' and exactly 7 letters - Count: " + listView.getItems().size());
    }
    
    // Show most active user 
    @FXML
    private void showMostActiveUserHandle(ActionEvent event) {
        if (tasksMap.isEmpty()) {
            resultLabel.setText("No tasks available");
            return;
        }
        
        Map.Entry<String, Long> mostActive = tasksMap.values().stream()
                .collect(Collectors.groupingBy(Task::getAddedBy, Collectors.counting()))
                .entrySet().stream()
                .max(Map.Entry.comparingByValue())
                .orElse(null);
        
        if (mostActive != null) {
            resultLabel.setText("Most active user: " + mostActive.getKey() + " (" + mostActive.getValue() + " tasks)");
        } else {
            resultLabel.setText("No users found");
        }
    }
    
    // Count open and closed tasks
    @FXML
    private void countOpenCloseTasksHandle(ActionEvent event) {
        long openCount = tasksMap.values().stream()
                .filter(t -> t.getStatus().equalsIgnoreCase("open"))
                .count();
        long closedCount = tasksMap.values().stream()
                .filter(t -> t.getStatus().equalsIgnoreCase("closed"))
                .count();
        resultLabel.setText("Open: " + openCount + " | Closed: " + closedCount);
    }
    
    // Count tasks 
    @FXML
    private void countTasksByPersonHandle(ActionEvent event) {
        TextInputDialog dialog = new TextInputDialog();
        dialog.setTitle("Count Tasks by Person");
        dialog.setHeaderText("Enter person's name (e.g., Sami)");
        dialog.setContentText("Name:");
        
        Optional<String> result = dialog.showAndWait();
        result.ifPresent(person -> {
            long count = tasksMap.values().stream()
                    .filter(t -> t.getAddedBy().equalsIgnoreCase(person))
                    .count();
            resultLabel.setText("Tasks added by " + person + ": " + count);
        });
    }
    
    // Show all tasks 
    @FXML
    private void showAllTasksHandle(ActionEvent event) {
        displayAllTasks();
        resultLabel.setText("All tasks");
    }
    
    // Helper method 
    private void showAlert(String title, String message, Alert.AlertType type) {
        Alert alert = new Alert(type);
        alert.setTitle(title);
        alert.setHeaderText(null);
        alert.setContentText(message);
        alert.showAndWait();
    }
}