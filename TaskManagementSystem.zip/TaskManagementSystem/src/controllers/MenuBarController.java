package controllers;

import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Alert;
import javafx.scene.control.ChoiceDialog;
import javafx.scene.control.MenuBar;
import javafx.scene.control.MenuItem;
import javafx.stage.Stage;

public class MenuBarController implements Initializable {
    
    @FXML
    private MenuBar menubar;
    @FXML
    private MenuItem exitMenuItem;
    @FXML
    private MenuItem aboutMenuItem;
    @FXML
    private MenuItem changeFontMenuItem;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
     
    }
    
   
    @FXML
    private void exitHandle(ActionEvent event) {
        ((Stage) menubar.getScene().getWindow()).close();
    }
    
    // Show  dialog 
    @FXML
    private void aboutHandle(ActionEvent event) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle("About");
        alert.setHeaderText("Task Management System");
        alert.setContentText("Version: 1.0\nDeveloper:Dana\nCourse: Programming III Lab\nInstructor: Aya N. Alharazin");
        alert.showAndWait();
    }
    
    // Change font family, size, and style 
    @FXML
    private void changeFontHandle(ActionEvent event) {
        // Choose font family
        ChoiceDialog<String> fontDialog = new ChoiceDialog<>("Arial", "Arial", "Verdana", "Times New Roman", "Courier New", "Tahoma");
        fontDialog.setTitle("Font Family");
        fontDialog.setHeaderText("Choose font family");
        Optional<String> fontResult = fontDialog.showAndWait();
        
        // Choose font size
        ChoiceDialog<Integer> sizeDialog = new ChoiceDialog<>(14, 10, 12, 14, 16, 18, 20, 24);
        sizeDialog.setTitle("Font Size");
        sizeDialog.setHeaderText("Choose font size");
        Optional<Integer> sizeResult = sizeDialog.showAndWait();
        
        // Apply font changes
        if (fontResult.isPresent() && sizeResult.isPresent()) {
            menubar.getScene().getRoot().setStyle(
                "-fx-font-family: '" + fontResult.get() + "';" +
                "-fx-font-size: " + sizeResult.get() + "px;"
            );
        }
    }
}