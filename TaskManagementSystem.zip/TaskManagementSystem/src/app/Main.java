package app;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.BorderPane;
import javafx.stage.Stage;

public class Main extends Application {
    
    @Override
    public void start(Stage stage) throws Exception {
        // Load MenuBar and MainApp FXML files
        Parent menuBar = FXMLLoader.load(getClass().getResource("/views/MenuBar.fxml"));
        Parent mainUI = FXMLLoader.load(getClass().getResource("/views/MainApp.fxml"));
        
        BorderPane root = new BorderPane();
        root.setTop(menuBar);
        root.setCenter(mainUI);
        
        Scene scene = new Scene(root);
        stage.setScene(scene);
        stage.setTitle("Task Management System");
        stage.show();
    }
    
    public static void main(String[] args) {
        launch(args);
    }
}